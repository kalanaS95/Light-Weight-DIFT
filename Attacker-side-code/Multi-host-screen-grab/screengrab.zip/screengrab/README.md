# screengrab 
Screengrab is a tool for taking a screenshot on a Linux host.

# Build

## Pre-Reqs
libx11-dev
libpng-dev

```
apt-get install libx11-dev libpng-dev
```

# Usage

```
usage: ./screengrab <outputFileName> <optionalTitle>
```
